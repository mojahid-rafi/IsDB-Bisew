function showProp(o) {
    for (const key in o) {
        console.log("Key: " + key + " , value:  " + o[key]);
    }
}